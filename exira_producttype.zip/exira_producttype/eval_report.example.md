# Product-Type Extraction — Eval Report

**Model/backend:** `mock`  |  **Gold rows:** 40

## Accuracy

- Exact canonical accuracy: **67.5%**
- Category accuracy: **67.5%**
- Coverage (non-Generic): **62.5%**

## Throughput & tokens

- Records/sec (this run): 8000.0
- Cache hit rate: 0.0% | LLM calls: 40 | junk-filtered: 0
- Tokens in/out: 563/160

## Per-category accuracy

| Category | Correct/Total |
|---|---|
| Agri Inputs | 1/1 |
| Apparel | 1/3 |
| Automotive | 3/4 |
| Beverages | 2/2 |
| Building Materials | 0/1 |
| Chemicals | 0/1 |
| Dairy & Frozen | 2/2 |
| Electronics | 2/2 |
| Furniture | 1/1 |
| Generic | 2/2 |
| Grains | 1/1 |
| Home Appliances | 1/1 |
| Livestock | 2/3 |
| Machinery | 2/3 |
| Medical | 2/2 |
| Metals & Scrap | 1/1 |
| Packaging | 0/2 |
| Plastics | 1/2 |
| Seafood | 3/4 |
| Textiles | 0/2 |

## Cost projection at scale

- Volume (all-year unique): 847,839,298
- After dedup x0.74 & non-junk x0.6: **376,440,648** LLM calls
- GPU-hours @ 60,000 rec/hr: **6,274.0**
- Cost @ $0.6/hr: **Rs 3.16 lakh** (0.00084 Rs/rec)

## Misclassification samples

| Country | Description | Gold | Pred |
|---|---|---|---|
| Malaysia | FOAM TRAY CP4 20 BAG X 2.70 KGM | PKG.0002 | GEN.0000 |
| Bangladesh | Toilet Linen And Kitchen Linen Of Terry Fabrics Of Cotton | TEX.0001 | GEN.0000 |
| Bangladesh | Women'S Or Girls' Night Dresses Pyjama Of Cotton Knitted Or Croched | APP.0002 | GEN.0000 |
| Nigeria | Worn clothing and other worn articles | APP.0006 | GEN.0000 |
| Pakistan | 1 LIVE HORSE MESSI Bay Mare Chip 981098108906342 | LIV.0001 | GEN.0000 |
| Colombia | MATERIAL AERONAUTICO DE USO EN AERONAVES RESOLUCION OEA 001938 | MAC.0001 | GEN.0000 |
| Uzbekistan | A car driven by an electric engine DONGFENG Fengshen Aeolus L7 120 kW | VEH.0001 | GEN.0000 |
| Turkey | CERAMIC WALL TILES GLAZED 30X60 CM FIRST QUALITY | BLD.0001 | GEN.0000 |
| Ghana | HDPE PLASTIC GRANULES INJECTION GRADE 25KG BAGS | PLA.0002 | GEN.0000 |
| Peru | FROZEN WHOLE FISH HAKE MERLUCCIUS GAYI 20KG BLOCKS | SEA.0002 | GEN.0000 |
| Malaysia | POLYPROPYLENE WOVEN BAGS EMPTY 50KG CAPACITY | PKG.0001 | GEN.0000 |
| India | COTTON KNITTED FABRIC GREIGE 180 GSM SINGLE JERSEY | TEX.0001 | GEN.0000 |
| Ghana | UREA FERTILISER 46% NITROGEN PRILLED 50KG BAGS | CHE.0002 | GEN.0000 |
