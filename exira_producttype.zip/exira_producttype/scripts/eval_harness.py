#!/usr/bin/env python3
"""
eval_harness.py — measure a candidate light model on a labelled gold set.

Reports:
  - Exact canonical accuracy (predicted canonical_id == gold_canonical_id)
  - Category accuracy (top-level)
  - Coverage (share resolved to a real node, not Generic/Unknown)
  - Cache hit-rate, throughput (rec/s), tokens in/out
  - Per-category breakdown + misclassification samples
  - Cost projection at your real volumes (ties to the cost model)

Usage (mock, offline demo):
  python scripts/eval_harness.py --gold data/gold_eval_seed.csv \
      --ontology ontology.pkl --backend mock --report eval_report.md

Usage (real):
  python scripts/eval_harness.py --gold data/gold_eval_seed.csv \
      --ontology ontology.pkl --backend vllm \
      --base-url http://localhost:8000 --model Qwen2.5-7B-Instruct \
      --report eval_report.md
"""
import argparse
import csv
import json
import pickle
import sys
import os
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.cache import Cache          # noqa: E402
from src.llm_client import LLMClient  # noqa: E402
from src.pipeline import Pipeline     # noqa: E402

# your real volumes (all-year unique descriptions) for cost projection
DEFAULT_VOLUME = 847_839_298
DEFAULT_DEDUP = 0.74
DEFAULT_PROC = 0.60


def load_gold(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", default="data/gold_eval_seed.csv")
    ap.add_argument("--ontology", default="ontology.pkl")
    ap.add_argument("--backend", default="mock", choices=["mock", "vllm"])
    ap.add_argument("--base-url"); ap.add_argument("--model")
    ap.add_argument("--report", default="eval_report.md")
    ap.add_argument("--preds", default="eval_predictions.csv")
    # cost projection knobs
    ap.add_argument("--volume", type=int, default=DEFAULT_VOLUME)
    ap.add_argument("--dedup", type=float, default=DEFAULT_DEDUP)
    ap.add_argument("--proc", type=float, default=DEFAULT_PROC)
    ap.add_argument("--gpu-usd-hr", type=float, default=0.60)
    ap.add_argument("--throughput", type=int, default=60000)
    ap.add_argument("--fx", type=float, default=84.0)
    a = ap.parse_args()

    onto = pickle.load(open(a.ontology, "rb"))
    llm = LLMClient(backend=a.backend, base_url=a.base_url, model=a.model)
    pipe = Pipeline(onto, llm, Cache("memory"), use_junk_filter=True)

    gold = load_gold(a.gold)
    descs = [g["raw_description"] for g in gold]
    results, st = pipe.run(descs)

    n = len(gold)
    exact = cat_ok = covered = 0
    by_cat = defaultdict(lambda: [0, 0])   # cat -> [correct, total]
    by_country = defaultdict(lambda: [0, 0])
    errors = []
    with open(a.preds, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["country", "description", "gold_id", "pred_id",
                    "pred_name", "pred_category", "confidence", "correct"])
        for g, r in zip(gold, results):
            ok = (r.canonical_id == g["gold_canonical_id"])
            catok = (r.category == g["gold_category"])
            exact += ok
            cat_ok += catok
            covered += (r.canonical_id != "GEN.0000")
            by_cat[g["gold_category"]][0] += ok
            by_cat[g["gold_category"]][1] += 1
            by_country[g.get("country", "?")][0] += ok
            by_country[g.get("country", "?")][1] += 1
            if not ok:
                errors.append((g.get("country", "?"), g["raw_description"][:70],
                               g["gold_canonical_id"], r.canonical_id))
            w.writerow([g.get("country", "?"), g["raw_description"][:120],
                        g["gold_canonical_id"], r.canonical_id, r.canonical_name,
                        r.category, r.confidence, ok])

    metrics = {
        "n": n,
        "exact_canonical_accuracy": round(exact / n, 4),
        "category_accuracy": round(cat_ok / n, 4),
        "coverage_non_generic": round(covered / n, 4),
        "throughput_rec_per_sec": st.as_dict()["records_per_sec"],
        "cache_hit_rate": st.as_dict()["cache_hit_rate"],
        "tokens_in": st.tokens_in, "tokens_out": st.tokens_out,
        "junk_filtered": st.junk, "llm_calls": st.llm_calls,
        "backend": a.backend, "model": a.model or a.backend,
    }

    # cost projection at scale
    calls = a.volume * a.dedup * a.proc
    gpu_hrs = calls / a.throughput
    inr = gpu_hrs * a.gpu_usd_hr * a.fx
    proj = {
        "effective_llm_calls": int(calls),
        "gpu_hours": round(gpu_hrs, 1),
        "cost_inr": round(inr),
        "cost_inr_lakh": round(inr / 1e5, 2),
        "cost_per_record_inr": round(a.gpu_usd_hr * a.fx / a.throughput, 6),
    }

    # ---- markdown report
    with open(a.report, "w", encoding="utf-8") as f:
        f.write(f"# Product-Type Extraction — Eval Report\n\n")
        f.write(f"**Model/backend:** `{metrics['model']}`  |  **Gold rows:** {n}\n\n")
        f.write("## Accuracy\n\n")
        f.write(f"- Exact canonical accuracy: **{metrics['exact_canonical_accuracy']:.1%}**\n")
        f.write(f"- Category accuracy: **{metrics['category_accuracy']:.1%}**\n")
        f.write(f"- Coverage (non-Generic): **{metrics['coverage_non_generic']:.1%}**\n\n")
        f.write("## Throughput & tokens\n\n")
        f.write(f"- Records/sec (this run): {metrics['throughput_rec_per_sec']}\n")
        f.write(f"- Cache hit rate: {metrics['cache_hit_rate']:.1%} | LLM calls: {metrics['llm_calls']} | junk-filtered: {metrics['junk_filtered']}\n")
        f.write(f"- Tokens in/out: {metrics['tokens_in']}/{metrics['tokens_out']}\n\n")
        f.write("## Per-category accuracy\n\n| Category | Correct/Total |\n|---|---|\n")
        for c, (ok, tot) in sorted(by_cat.items()):
            f.write(f"| {c} | {ok}/{tot} |\n")
        f.write("\n## Cost projection at scale\n\n")
        f.write(f"- Volume (all-year unique): {a.volume:,}\n")
        f.write(f"- After dedup x{a.dedup} & non-junk x{a.proc}: **{proj['effective_llm_calls']:,}** LLM calls\n")
        f.write(f"- GPU-hours @ {a.throughput:,} rec/hr: **{proj['gpu_hours']:,}**\n")
        f.write(f"- Cost @ ${a.gpu_usd_hr}/hr: **Rs {proj['cost_inr_lakh']} lakh** ({proj['cost_per_record_inr']} Rs/rec)\n\n")
        if errors:
            f.write("## Misclassification samples\n\n| Country | Description | Gold | Pred |\n|---|---|---|---|\n")
            for c, d, gid, pid in errors[:25]:
                f.write(f"| {c} | {d} | {gid} | {pid} |\n")

    print(json.dumps({"metrics": metrics, "cost_projection": proj}, indent=2))
    print(f"\nreport -> {a.report}\npredictions -> {a.preds}")


if __name__ == "__main__":
    main()
