#!/usr/bin/env python3
"""
run_batch.py — score a column of descriptions -> canonical product types.

Usage (mock, offline):
  python scripts/run_batch.py --in data/gold_eval_seed.csv --col raw_description \
      --ontology ontology.pkl --backend mock --out predictions.csv

Usage (production, vLLM):
  python scripts/run_batch.py --in shipments.csv --col product_description \
      --ontology ontology.pkl --backend vllm \
      --base-url http://localhost:8000 --model Qwen2.5-7B-Instruct \
      --out predictions.csv
"""
import argparse
import csv
import json
import pickle
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.cache import Cache          # noqa: E402
from src.llm_client import LLMClient  # noqa: E402
from src.pipeline import Pipeline     # noqa: E402


def read_col(path, col):
    rows = []
    if path.lower().endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True)
        ws = wb.active
        headers = [str(c) if c is not None else "" for c in next(ws.iter_rows(values_only=True))]
        idx = headers.index(col)
        for r in ws.iter_rows(min_row=2, values_only=True):
            rows.append(r[idx] if idx < len(r) and r[idx] is not None else "")
    else:
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                rows.append(row.get(col, ""))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--col", required=True)
    ap.add_argument("--ontology", default="ontology.pkl")
    ap.add_argument("--backend", default="mock", choices=["mock", "vllm"])
    ap.add_argument("--base-url"); ap.add_argument("--model")
    ap.add_argument("--cache", default="memory", choices=["memory", "sqlite"])
    ap.add_argument("--no-junk-filter", action="store_true")
    ap.add_argument("--out", default="predictions.csv")
    a = ap.parse_args()

    onto = pickle.load(open(a.ontology, "rb"))
    llm = LLMClient(backend=a.backend, base_url=a.base_url, model=a.model)
    cache = Cache(backend=a.cache)
    pipe = Pipeline(onto, llm, cache, use_junk_filter=not a.no_junk_filter)

    descs = read_col(a.inp, a.col)
    results, st = pipe.run([str(d) for d in descs])

    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["description", "canonical_id", "canonical_name", "category",
                    "confidence", "source"])
        for d, r in zip(descs, results):
            w.writerow([str(d)[:200], r.canonical_id, r.canonical_name,
                        r.category, r.confidence, r.source])

    print(json.dumps(st.as_dict(), indent=2))
    print(f"\nwrote {a.out}")
    if onto.candidates:
        print("\nTop unmapped phrases (ontology-growth candidates):")
        for p, c in onto.top_candidates(15):
            print(f"  {c:>4}  {p}")


if __name__ == "__main__":
    main()
