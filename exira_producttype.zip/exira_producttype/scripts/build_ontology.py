#!/usr/bin/env python3
"""
build_ontology.py — load the seed ontology, embed nodes+aliases, save.

Usage:
  python scripts/build_ontology.py --seed data/ontology_seed.csv \
      --embedder auto --out ontology.pkl
"""
import argparse
import pickle
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.ontology import Ontology  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", default="data/ontology_seed.csv")
    ap.add_argument("--embedder", default="auto",
                    choices=["auto", "st", "hashing"])
    ap.add_argument("--model", default="BAAI/bge-small-en-v1.5")
    ap.add_argument("--threshold", type=float, default=0.62)
    ap.add_argument("--out", default="ontology.pkl")
    a = ap.parse_args()

    onto = Ontology.from_csv(a.seed, embedder=a.embedder,
                             model_name=a.model, threshold=a.threshold)
    with open(a.out, "wb") as f:
        pickle.dump(onto, f)
    kind = type(onto.embedder).__name__
    print(f"Ontology: {len(onto.nodes)} canonical nodes, "
          f"{len(onto._alias_names)} aliases, embedder={kind}, "
          f"threshold={a.threshold} -> {a.out}")


if __name__ == "__main__":
    main()
