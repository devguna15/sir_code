"""
normalize.py — Stage 0 of the product-type pipeline.

Two jobs:
  1. normalize_text(): light cleanup of a raw customs description for the LLM.
  2. signature(): a *coarse* content key used both for (a) the cache and
     (b) deduplication. Two descriptions that differ only in invoice numbers,
     dates, weights, PO/HS codes collapse to the same signature, so we only
     ever pay for the LLM once per distinct signature.

Measured on the 57-country sample: signature-dedup takes raw-distinct rows
from ~58% down to ~43% of volume, i.e. ~26% fewer LLM calls on top of the
year-level uniqueness you already have.
"""
from __future__ import annotations
import re
import unicodedata

# tokens that carry no product meaning — dropped from the signature
_STOP = {
    "the", "and", "for", "with", "not", "nes", "other", "others", "misc",
    "as", "per", "inv", "invoice", "no", "nos", "qty", "pcs", "pc", "set",
    "kg", "kgs", "gm", "gms", "mt", "ton", "tons", "ltr", "ml", "cm", "mm",
    "packed", "packing", "package", "packages", "carton", "cartons", "bag",
    "bags", "box", "boxes", "net", "gross", "weight", "wt", "hs", "code",
    "date", "dt", "po", "sb", "ref", "reference", "origin", "made", "in",
    "of", "to", "from", "x", "each", "total", "item", "items",
}

_DATE = re.compile(r"\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b|\b\d{4}-\d{2}-\d{2}\b")
_NUM = re.compile(r"\d+([.,]\d+)?")
# alphanumeric codes like WA26DG5500AV, HBLGBOR, 981098108906342, NCM7602
_CODE = re.compile(r"\b(?=[a-z0-9-]*\d)(?=[a-z0-9-]*[a-z])[a-z0-9-]{5,}\b", re.I)
_WS = re.compile(r"\s+")
_PUNCT = re.compile(r"[^\w\s]", re.UNICODE)


def normalize_text(s: str) -> str:
    """Cleanup for the LLM input: unicode-normalize, collapse whitespace."""
    if s is None:
        return ""
    s = unicodedata.normalize("NFKC", str(s))
    s = s.replace("_x000D_", " ").replace("\r", " ").replace("\n", " ")
    return _WS.sub(" ", s).strip()


def signature(s: str) -> str:
    """
    Coarse content signature: lowercase, strip dates/numbers/codes/punct,
    drop stopwords & units, keep content words (len>2), return sorted-unique.
    Non-Latin scripts are preserved (tokens kept as-is) so Cyrillic/etc. still
    deduplicate against themselves.
    """
    s = normalize_text(s).lower()
    s = _DATE.sub(" ", s)
    s = _CODE.sub(" ", s)
    s = _NUM.sub(" ", s)
    s = _PUNCT.sub(" ", s)
    toks = [t for t in s.split() if len(t) > 2 and t not in _STOP]
    return " ".join(sorted(set(toks)))


def is_probably_junk(s: str) -> bool:
    """
    Cheap pre-filter for non-product rows (documentation, empty, all-punct,
    'general cargo' boilerplate). Catches ~half of records in the sample so
    they never hit the LLM — they map straight to the Generic/Unknown node.
    """
    sig = signature(s)
    if len(sig) < 3:
        return True
    junk_markers = (
        "general", "cargo", "merchandise", "documentation", "document",
        "shipment", "consolidated", "said", "contain", "sample",
    )
    words = sig.split()
    if len(words) <= 2 and any(w in junk_markers for w in words):
        return True
    return False
