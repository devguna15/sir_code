"""
ontology.py — Stage 3: map the LLM's free phrase onto a FIXED canonical node.

This is what turns an inconsistent model into a consistent product ontology.
"Frozen Shrimp", "Frozen Vannamei Shrimp", "FROZEN SHRIMPS (VANNAMEI)" all
embed near the same node and collapse to one canonical_id. If nothing is close
enough (cosine < threshold) the phrase is parked as a *candidate* for periodic
human-reviewed ontology growth, and the record is returned as 'Unknown'.

Embedder:
  - sentence-transformers (e.g. BAAI/bge-small-en-v1.5) if installed — recommended.
  - offline char-n-gram hashing fallback (pure numpy) so this runs with no
    model download (used in this demo). Swap in the real embedder in prod.
"""
from __future__ import annotations
import hashlib
import csv
from dataclasses import dataclass
import numpy as np


@dataclass
class Node:
    canonical_id: str
    canonical_name: str
    category: str


class _HashingEmbedder:
    """Char 3/4-gram hashing -> L2-normalised vector. Dependency-free."""
    def __init__(self, dim=512):
        self.dim = dim

    def _vec(self, text: str) -> np.ndarray:
        text = f"^{text.lower().strip()}$"
        v = np.zeros(self.dim, dtype=np.float32)
        for n in (3, 4):
            for i in range(len(text) - n + 1):
                g = text[i:i + n]
                h = int(hashlib.md5(g.encode()).hexdigest(), 16) % self.dim
                v[h] += 1.0
        nrm = np.linalg.norm(v)
        return v / nrm if nrm else v

    def encode(self, texts: list[str]) -> np.ndarray:
        return np.vstack([self._vec(t) for t in texts])


class _STEmbedder:
    def __init__(self, model_name):
        from sentence_transformers import SentenceTransformer
        self.m = SentenceTransformer(model_name)

    def encode(self, texts: list[str]) -> np.ndarray:
        return np.asarray(
            self.m.encode(texts, normalize_embeddings=True), dtype=np.float32
        )


class Ontology:
    def __init__(self, embedder="auto", model_name="BAAI/bge-small-en-v1.5",
                 threshold=0.62):
        self.threshold = threshold
        self.nodes: list[Node] = []
        self._mat: np.ndarray | None = None
        self.candidates: dict[str, int] = {}  # unmapped phrase -> count
        if embedder == "hashing":
            self.embedder = _HashingEmbedder()
        elif embedder == "st":
            self.embedder = _STEmbedder(model_name)
        else:  # auto: try ST, fall back to hashing
            try:
                self.embedder = _STEmbedder(model_name)
            except Exception:
                self.embedder = _HashingEmbedder()

    @classmethod
    def from_csv(cls, path, **kw):
        """CSV columns: canonical_id, canonical_name, category, aliases(|-sep)."""
        o = cls(**kw)
        names, nodes = [], []
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                node = Node(row["canonical_id"], row["canonical_name"], row["category"])
                nodes.append(node)
                aliases = [row["canonical_name"]]
                if row.get("aliases"):
                    aliases += [a.strip() for a in row["aliases"].split("|") if a.strip()]
                # index every alias to the same node
                for a in aliases:
                    names.append((a, len(nodes) - 1))
        o.nodes = nodes
        o._alias_names = [a for a, _ in names]
        o._alias_node = [i for _, i in names]
        o._mat = o.embedder.encode(o._alias_names)
        return o

    def map(self, phrase: str):
        """Return (Node|None, cosine_similarity)."""
        if not phrase or phrase.strip().lower() in ("unknown", "n/a", ""):
            return None, 0.0
        q = self.embedder.encode([phrase])[0]
        sims = self._mat @ q
        j = int(np.argmax(sims))
        sim = float(sims[j])
        if sim >= self.threshold:
            return self.nodes[self._alias_node[j]], sim
        self.candidates[phrase] = self.candidates.get(phrase, 0) + 1
        return None, sim

    def top_candidates(self, k=25):
        return sorted(self.candidates.items(), key=lambda x: -x[1])[:k]
