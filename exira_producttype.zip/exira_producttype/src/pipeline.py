"""
pipeline.py — orchestration: normalize -> junk-filter -> cache -> LLM -> ontology.

Only unique cache-missing signatures reach the LLM, and only non-junk rows
reach it at all. Emits per-run telemetry (cache hit rate, LLM calls, tokens,
throughput, projected cost) so a benchmark run doubles as a cost measurement.
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field

from .normalize import signature, normalize_text, is_probably_junk
from .cache import Cache, CanonResult
from .llm_client import LLMClient
from .ontology import Ontology

GENERIC = CanonResult("GEN.0000", "General / Unknown", "Generic", 1.0, "junk-filter")


@dataclass
class RunStats:
    n: int = 0
    junk: int = 0
    cache_hits: int = 0
    llm_calls: int = 0            # unique signatures sent to the model
    unique_signatures: int = 0
    mapped: int = 0               # resolved to a real ontology node
    unmapped: int = 0            # LLM answered but below ontology threshold
    tokens_in: int = 0
    tokens_out: int = 0
    seconds: float = 0.0

    def as_dict(self):
        d = self.__dict__.copy()
        d["cache_hit_rate"] = round(self.cache_hits / self.n, 4) if self.n else 0
        d["records_per_sec"] = round(self.n / self.seconds, 1) if self.seconds else 0
        d["llm_call_ratio"] = round(self.llm_calls / self.n, 4) if self.n else 0
        return d


class Pipeline:
    def __init__(self, ontology: Ontology, llm: LLMClient, cache: Cache,
                 use_junk_filter=True, llm_batch=256):
        self.onto = ontology
        self.llm = llm
        self.cache = cache
        self.use_junk_filter = use_junk_filter
        self.llm_batch = llm_batch

    def run(self, descriptions: list[str]):
        t0 = time.time()
        st = RunStats(n=len(descriptions))
        results: list[CanonResult] = [None] * len(descriptions)  # type: ignore

        # 1) normalize + signature; route junk & cache hits; collect misses
        miss_idx_by_sig: dict[str, list[int]] = {}
        for i, raw in enumerate(descriptions):
            if self.use_junk_filter and is_probably_junk(raw):
                results[i] = GENERIC
                st.junk += 1
                continue
            sig = signature(raw)
            hit = self.cache.get(sig)
            if hit is not None:
                results[i] = hit
                st.cache_hits += 1
            else:
                miss_idx_by_sig.setdefault(sig, []).append(i)

        st.unique_signatures = len(miss_idx_by_sig)

        # 2) one representative description per unique signature -> LLM (batched)
        sigs = list(miss_idx_by_sig.keys())
        reps = [normalize_text(descriptions[miss_idx_by_sig[s][0]]) for s in sigs]
        for b in range(0, len(reps), self.llm_batch):
            batch_sigs = sigs[b:b + self.llm_batch]
            batch_reps = reps[b:b + self.llm_batch]
            phrases = self.llm.propose(batch_reps)
            st.llm_calls += len(batch_reps)
            for sig, phrase in zip(batch_sigs, phrases):
                node, sim = self.onto.map(phrase)
                if node is not None:
                    res = CanonResult(node.canonical_id, node.canonical_name,
                                      node.category, round(sim, 3), "llm")
                    st.mapped += 1
                else:
                    res = CanonResult("GEN.0000", "General / Unknown", "Generic",
                                      round(sim, 3), "unmapped")
                    st.unmapped += 1
                self.cache.put(sig, res)
                for i in miss_idx_by_sig[sig]:
                    results[i] = res

        st.tokens_in = self.llm.tokens_in
        st.tokens_out = self.llm.tokens_out
        st.seconds = round(time.time() - t0, 3)
        return results, st
