"""
cache.py — Stage 1: signature -> canonical result cache.

Product type is coarse, so the cache hit rate climbs fast: once
'frozen shrimp vannamei' is resolved, every later description with the same
signature is answered for free. Backends:
  - 'memory' : dict (fast, per-process; good for a single batch job)
  - 'sqlite' : persistent across runs / shareable across workers
"""
from __future__ import annotations
import json
import sqlite3
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class CanonResult:
    canonical_id: str
    canonical_name: str
    category: str
    confidence: float
    source: str = "llm"  # llm | cache | junk-filter | ontology-exact


class Cache:
    def __init__(self, backend: str = "memory", path: str = "pt_cache.sqlite"):
        self.backend = backend
        self.hits = 0
        self.misses = 0
        if backend == "memory":
            self._d: dict[str, CanonResult] = {}
        elif backend == "sqlite":
            self._conn = sqlite3.connect(path)
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS cache (sig TEXT PRIMARY KEY, val TEXT)"
            )
            self._conn.commit()
        else:
            raise ValueError(f"unknown cache backend: {backend}")

    def get(self, sig: str) -> Optional[CanonResult]:
        if self.backend == "memory":
            r = self._d.get(sig)
        else:
            row = self._conn.execute(
                "SELECT val FROM cache WHERE sig=?", (sig,)
            ).fetchone()
            r = CanonResult(**json.loads(row[0])) if row else None
        if r is not None:
            self.hits += 1
            # return a copy tagged as a cache hit
            r = CanonResult(**{**asdict(r), "source": "cache"})
        else:
            self.misses += 1
        return r

    def put(self, sig: str, res: CanonResult) -> None:
        if self.backend == "memory":
            self._d[sig] = res
        else:
            self._conn.execute(
                "INSERT OR REPLACE INTO cache VALUES (?,?)",
                (sig, json.dumps(asdict(res))),
            )
            self._conn.commit()

    @property
    def hit_rate(self) -> float:
        n = self.hits + self.misses
        return self.hits / n if n else 0.0
