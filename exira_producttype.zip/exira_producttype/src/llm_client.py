"""
llm_client.py — Stage 2: the light LLM proposes a canonical product-type phrase.

Backends:
  - 'vllm'  : OpenAI-compatible /v1/chat/completions against a vLLM server
              running e.g. Qwen2.5-7B-Instruct or Llama-3.1-8B-Instruct.
              Uses a fixed system prompt (cached as a prefix by vLLM, so its
              prefill cost is paid once, not per record) + optional guided
              decoding to force short output.
  - 'mock'  : offline keyword heuristic so the whole pipeline runs with no GPU
              (for CI / plumbing tests / this demo). NOT for production accuracy.

Design intent: the model only has to emit a *reasonable* short noun phrase.
Consistency is enforced downstream by the ontology mapper, so the model does
not need to memorise the canonical vocabulary.
"""
from __future__ import annotations
import concurrent.futures as cf
import json
import re
from typing import Optional

SYSTEM_PROMPT = """You normalise messy customs/trade descriptions into a single CANONICAL PRODUCT TYPE.

Rules:
- Output ONLY the product type as a short noun phrase (2-4 words), Title Case.
- Be specific where the text supports it: "Frozen Vannamei Shrimp", "Milled White Rice", "Cotton T-Shirt" — never just "Shrimp"/"Rice"/"Shirt".
- Push brand, model, size, colour, flavour, grade, weight, quantity, part/HS numbers to NOTHING — they are attributes, not the type.
- If the text is a document, generic ("general cargo"), or unintelligible, output exactly: Unknown
- No explanations, no punctuation, no quotes. One line only.

Examples:
"SAMSUNG GALAXY S26 512GB NEW OEM US SPEC BLUE" -> Smartphone
"1650 CARTONS FROZEN COOKED PEELED VANNAMEI SHRIMP" -> Frozen Vannamei Shrimp
"NEW SHANTUI SD22 BULLDOZER C/W ACCESSORIES" -> Bulldozer
"41600 BAGS PAKISTAN WHITE RICE 5PCT BROKENS DOUBLE POLISHED" -> Milled White Rice
"THIS SHIPMENT CONTAINS NO SOLID WOOD PACKING" -> Unknown
"""

_CLEAN = re.compile(r'^[\s"\'`\-*.:]+|[\s"\'`\-*.:]+$')


def _postprocess(text: str) -> str:
    line = text.strip().splitlines()[0] if text.strip() else "Unknown"
    line = _CLEAN.sub("", line)
    return line[:60] if line else "Unknown"


class LLMClient:
    def __init__(self, backend="mock", base_url=None, model=None,
                 max_workers=32, timeout=30, guided=True):
        self.backend = backend
        self.base_url = base_url
        self.model = model
        self.max_workers = max_workers
        self.timeout = timeout
        self.guided = guided
        self.tokens_in = 0
        self.tokens_out = 0
        if backend == "vllm":
            import requests  # noqa: F401  (fail fast if missing)

    # ---- public: batch of raw descriptions -> list of proposed type phrases
    def propose(self, descriptions: list[str]) -> list[str]:
        if self.backend == "mock":
            return [self._mock(d) for d in descriptions]
        with cf.ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            return list(ex.map(self._one_vllm, descriptions))

    # ---- vLLM (OpenAI-compatible) single call
    def _one_vllm(self, desc: str) -> str:
        import requests
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": desc[:400]},
            ],
            "temperature": 0.0,
            "max_tokens": 16,
        }
        if self.guided:
            # vLLM guided decoding: keep output to a short single line
            body["guided_regex"] = r"[A-Za-z][A-Za-z /&'-]{1,58}"
        try:
            r = requests.post(
                f"{self.base_url}/v1/chat/completions",
                json=body, timeout=self.timeout,
            )
            r.raise_for_status()
            j = r.json()
            u = j.get("usage", {})
            self.tokens_in += u.get("prompt_tokens", 0)
            self.tokens_out += u.get("completion_tokens", 0)
            return _postprocess(j["choices"][0]["message"]["content"])
        except Exception:
            return "Unknown"

    # ---- offline mock: crude keyword mapper (plumbing only)
    _RULES = [
        (r"shrimp|vannamei|prawn", "Frozen Vannamei Shrimp"),
        (r"\brice\b", "Milled White Rice"),
        (r"\btea\b", "Black Tea"),
        (r"ice ?cream", "Ice Cream"),
        (r"bulldozer|excavator|loader", "Earthmoving Machine"),
        (r"syringe", "Medical Syringe"),
        (r"washing machine", "Washing Machine"),
        (r"refrigerator|fridge", "Refrigerator"),
        (r"cellular|smartphone|galaxy|iphone|telefono", "Smartphone"),
        (r"t-?shirt|tshirt", "Cotton T-Shirt"),
        (r"shirt", "Shirt"),
        (r"trouser|pant\b|pants", "Trousers"),
        (r"footwear|shoe|sandal", "Footwear"),
        (r"tupperware|food container", "Plastic Food Container"),
        (r"aluminium scrap|aluminum scrap|sucata", "Aluminium Scrap"),
        (r"scrap", "Metal Scrap"),
        (r"cow|cattle|heifer|bovine", "Live Cattle"),
        (r"machine parts|spare parts|parts", "Machine Parts"),
        (r"tyre|tire", "Tyre"),
        (r"sofa|cabinet|table|furniture", "Furniture"),
        (r"wine", "Wine"),
        (r"animal feed|feed additive", "Animal Feed Additive"),
        (r"tractor|toyota|vehicle|motor car", "Motor Vehicle"),
    ]

    def _mock(self, desc: str) -> str:
        d = desc.lower()
        self.tokens_in += max(1, len(desc) // 4)
        self.tokens_out += 4
        for pat, label in self._RULES:
            if re.search(pat, d):
                return label
        return "Unknown"
