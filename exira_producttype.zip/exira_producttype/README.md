# Exira — Canonical Product-Type Pipeline + Eval Harness

Two deliverables for Action 1 (canonical product type for **all** countries on a
light LLM + light GPU):

1. **Reference pipeline** — `normalize → junk-filter → cache → light-LLM → embed → map-to-ontology`
2. **Eval harness** — measures a candidate 7-8B model's product-type accuracy on a
   labelled gold set and projects cost at your real volumes.

The whole thing runs **offline** (mock LLM + hashing embedder) so you can inspect
the plumbing with no GPU, then swap in a vLLM endpoint + a real embedder for
production accuracy numbers.

## Why this design

The current pipeline emits 13k+ near-duplicate product-type strings
(`General Trade Goods` / `General Trade Good` / `General Cargo` …). Making the
*model* responsible for consistency doesn't work. Here consistency is a **system
property**: the light model only proposes a rough phrase, and the **ontology
mapper** (embedding + nearest-neighbour to a fixed node list) collapses variants
onto one `canonical_id`. So "Frozen Shrimp", "Frozen Vannamei Shrimp" and
"FROZEN SHRIMPS VANNAMEI" all resolve to `SEA.0001`.

Two cost levers are built in and measured on your data:
- **Signature dedup** — invoice numbers / dates / codes / weights are stripped to
  a content signature; identical signatures hit the **cache**, not the LLM.
- **Junk pre-filter** — generic/documentation/empty rows skip the LLM entirely.

On 999 real Panama-BL rows this cut LLM calls to **0.32×** volume.

## Layout

```
src/normalize.py     signature + junk filter (Stage 0/1)
src/cache.py         signature -> canonical cache (memory | sqlite)
src/llm_client.py    vLLM (OpenAI-compatible) | mock backend  (Stage 2)
src/ontology.py      embedding + nearest-node mapper           (Stage 3)
src/pipeline.py      orchestration + telemetry
scripts/build_ontology.py   embed the seed ontology -> ontology.pkl
scripts/run_batch.py        score a CSV/XLSX column
scripts/eval_harness.py     accuracy + cost report on a gold set
data/ontology_seed.csv      50 canonical nodes, 270 aliases (extend this)
data/gold_eval_seed.csv     40 labelled rows (extend to 2-5k for a real eval)
config.yaml, requirements.txt
```

## Quick start (offline demo — no GPU)

```bash
pip install numpy openpyxl
python scripts/build_ontology.py --embedder hashing --out ontology.pkl
python scripts/eval_harness.py --gold data/gold_eval_seed.csv \
    --ontology ontology.pkl --backend mock --report eval_report.md
```

## Production (real accuracy)

1. Serve the light model on the GPU box:
   ```bash
   python -m vllm.entrypoints.openai.api_server \
     --model Qwen2.5-7B-Instruct --enable-prefix-caching \
     --max-num-seqs 256 --port 8000
   ```
2. Build the ontology with a real embedder:
   ```bash
   pip install sentence-transformers
   python scripts/build_ontology.py --embedder st \
     --model BAAI/bge-small-en-v1.5 --out ontology.pkl
   ```
3. Evaluate the candidate model:
   ```bash
   python scripts/eval_harness.py --gold data/gold_eval_seed.csv \
     --ontology ontology.pkl --backend vllm \
     --base-url http://localhost:8000 --model Qwen2.5-7B-Instruct \
     --report eval_report.md
   ```
4. Run the full batch:
   ```bash
   python scripts/run_batch.py --in shipments.csv --col product_description \
     --ontology ontology.pkl --backend vllm \
     --base-url http://localhost:8000 --model Qwen2.5-7B-Instruct \
     --cache sqlite --out predictions.csv
   ```

## How to trust the accuracy number

The mock backend is a crude keyword mapper — treat its accuracy as a **plumbing
check only**. For a real go/no-go on a light model:

1. Expand `data/gold_eval_seed.csv` to **2,000–5,000 human-labelled rows**,
   stratified across countries and categories (the seed shows the format).
2. Run the harness against 2-3 candidate models (Qwen2.5-7B, Llama-3.1-8B, and a
   stronger reference like a 70B or your frontier API as the ceiling).
3. Compare **exact canonical accuracy**, **category accuracy**, and **coverage**.
   Gate: promote the cheapest model that clears your accuracy bar; route
   low-confidence rows (ontology cosine below threshold) to the stronger model.

The harness prints a cost projection alongside accuracy so you see the
accuracy/cost trade-off in one place. Growth candidates (phrases that matched no
node) are logged for periodic human-reviewed ontology expansion.
